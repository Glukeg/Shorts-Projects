import segno

qrcode = segno.make_qr(content='https://t.me/glukeg_official')
qrcode.save(
    out='qrcode.png',
    scale=10
)
