from MukeshAPI import api

image = api.ai_image('Shark in the ocean')

with open(file='image.jpg', mode='wb') as file:
    file.write(image)
