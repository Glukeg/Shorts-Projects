import pytz
from datetime import datetime

tz = pytz.timezone('Europe/Moscow')
current_datetime = datetime.now(tz)
print(current_datetime)
