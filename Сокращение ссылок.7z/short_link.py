import pyshorteners

pyshorteners = pyshorteners.Shortener()

url = input("Введите URL: ")
short_url = pyshorteners.clckru.short(url)

print(f"Сокращенный URL: {short_url}")

