from gtts import gTTS

text = input('Введите текст: ')

speech = gTTS(text=text, lang='ru')
speech.save('audio.mp3')
