while True:
    print(eval(input('Введите пример: ')))
