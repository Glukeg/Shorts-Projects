import random

random_number = random.randint(a=1, b=10)
print(f'Рандомное число: {random_number}')
