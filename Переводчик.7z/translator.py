from googletrans import Translator

translator = Translator()

text = input('Введите текст: ')

translation = translator.translate(text=text, dest='en')
print('Перевод:', translation.text)
